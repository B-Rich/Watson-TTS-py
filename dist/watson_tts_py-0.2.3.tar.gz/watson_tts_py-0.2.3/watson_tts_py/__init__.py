#__all__ = ["watson_tts_py"]
from watson_tts_py.watson_tts_py import *
